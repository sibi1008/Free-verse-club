FREEVERSE CLUB WEBSITE
========================
A responsive one-page starter website for the Freeverse student club.

Files:
- index.html  -> website content
- style.css   -> design
- script.js   -> mobile menu

To customize:
1. Open index.html.
2. Replace placeholder names, event details, Instagram and email.
3. Replace the Google Forms link with your actual registration form.
4. Upload the folder to any static website host.

This is a starter design; the logo, real club information, photos, team members and links can be added next.
